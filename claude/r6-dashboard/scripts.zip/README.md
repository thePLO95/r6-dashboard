# R6 Dashboard
1. Copia `seasonData.js` a `raw/` y tus `data_XX.js` a `raw/allMatches/` (también vale un `.json` con el array).
2. `npm install`
3. `npm run data`  → raw -> `public/data/*.json` (fichero a fichero; ya no hace falta `index_test.html` ni el objeto `users`)
4. `npm run dev`
