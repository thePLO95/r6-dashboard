import { useEffect, useState } from 'react';
import { loadIndex, loadPlayer, seasonSummary, type Index, type Metric, type PlayerData, type XAxis } from './data';
import RankEvolution from './RankEvolution';
import KDAEvolution from './KDAEvolution';
import PlaylistDistribution from './PlaylistDistribution';

const METRICS: [Metric, string][] = [['rating', 'Rank points'], ['progress', 'Progreso en la season'], ['netwins', 'Victorias − derrotas (todas las seasons)']];
const TABS = [['rank', 'Rango'], ['kda', 'K / D / A'], ['playlists', 'Playlists']] as const;
type Tab = (typeof TABS)[number][0];

export default function App() {
  const [index, setIndex] = useState<Index>();
  const [tab, setTab] = useState<Tab>('rank');
  const [sel, setSel] = useState<string[]>([]);   // comparación (pestaña Rango)
  const [focus, setFocus] = useState('');          // jugador único (K/D/A y Playlists)
  const [cache, setCache] = useState<Record<string, PlayerData>>({});
  const [season, setSeason] = useState('');
  const [metric, setMetric] = useState<Metric>('progress');
  const [x, setX] = useState<XAxis>('match');

  useEffect(() => { loadIndex().then((i) => { setIndex(i); setSel(i.players.slice(0, 2).map((p) => p.name)); setFocus(i.players[0]?.name ?? ''); setSeason(i.seasons[0]); }); }, []);
  const needed = tab === 'rank' ? sel : focus ? [focus] : [];
  useEffect(() => { needed.filter((n) => !cache[n]).forEach((n) => loadPlayer(n).then((p) => setCache((c) => ({ ...c, [n]: p })))); }, [tab, sel, focus]);

  if (!index) return <p>Cargando…</p>;
  const players = sel.map((n) => cache[n]).filter(Boolean);
  const fp = cache[focus];
  const toggle = (n: string) => setSel((s) => (s.includes(n) ? s.filter((v) => v !== n) : [...s, n]));
  const noRating = metric !== 'netwins' && players.every((p) => !seasonSummary(p, season));

  return (
    <main style={{ maxWidth: 1000, margin: '0 auto', padding: 16, fontFamily: 'system-ui, sans-serif' }}>
      <nav style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {TABS.map(([k, l]) => <button key={k} onClick={() => setTab(k)} style={{ padding: '6px 14px', fontWeight: tab === k ? 700 : 400 }}>{l}</button>)}
      </nav>

      {tab === 'rank' ? (<>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
          {index.players.map((p) => (
            <label key={p.name} style={{ border: '1px solid #8886', borderRadius: 16, padding: '2px 10px', background: sel.includes(p.name) ? '#4a90e233' : 'none' }}>
              <input type="checkbox" checked={sel.includes(p.name)} onChange={() => toggle(p.name)} /> {p.name}
            </label>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 12 }}>
          <select value={season} onChange={(e) => setSeason(e.target.value)}>{index.seasons.map((s) => <option key={s}>{s}</option>)}</select>
          <select value={metric} onChange={(e) => setMetric(e.target.value as Metric)}>{METRICS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          <select value={x} onChange={(e) => setX(e.target.value as XAxis)}><option value="match">Por partidas jugadas</option><option value="date">Por fecha</option></select>
        </div>
        {noRating && <p>⚠️ En {season} no hay rank points. Prueba la métrica «Victorias − derrotas».</p>}
        <RankEvolution players={players} season={season} metric={metric} x={x} />
        <table style={{ width: '100%', marginTop: 16, borderCollapse: 'collapse' }}>
          <thead><tr><th align="left">Jugador</th><th>Inicio</th><th>Fin</th><th>Progreso</th><th>Pico</th></tr></thead>
          <tbody>{players.map((p) => { const s = seasonSummary(p, season); return (
            <tr key={p.name}><td>{p.name}</td>{s ? <><td align="center">{s.start}</td><td align="center">{s.end}</td><td align="center">{s.net > 0 ? '+' : ''}{s.net}</td><td align="center">{s.peak}</td></> : <td colSpan={4} align="center">sin rank points</td>}</tr>); })}</tbody>
        </table>
      </>) : (<>
        <select value={focus} onChange={(e) => setFocus(e.target.value)} style={{ marginBottom: 12 }}>{index.players.map((p) => <option key={p.name}>{p.name}</option>)}</select>
        {!fp ? <p>Cargando…</p> : tab === 'kda' ? <KDAEvolution key={focus} player={fp} /> : <PlaylistDistribution player={fp} />}
      </>)}
    </main>
  );
}
