import type { Match } from './data';

export const seasonKey = (s: string) => { const m = /Y(\d+)S(\d+)/.exec(s); return m ? +m[1] * 10 + +m[2] : 0; };
// Playlists mostradas; cualquier otra ("134", etc.) se agrupa en "other"
export const PLAYLIST_GROUPS = ['ranked', 'standard', 'quick-match', 'siege-cup', 'event', 'arcade', 'dual-front', 'other'];
export const playlistGroup = (p: string) => (PLAYLIST_GROUPS.includes(p) && p !== 'other' ? p : 'other');
const r2 = (x: number) => Math.round(x * 100) / 100;

type Agg = { n: number; k: number; d: number; a: number; r: number };
// Solo partidas con kills/deaths/assists y rondas jugadas
const usable = (m: Match, playlist: string) => (playlist === 'all' || playlistGroup(m.playlist) === playlist) && m.k != null && m.d != null && m.a != null && !!m.rounds;
const agg = (ms: Match[]): Agg => ms.reduce((s, m) => ({ n: s.n + 1, k: s.k + m.k!, d: s.d + m.d!, a: s.a + m.a!, r: s.r + m.rounds! }), { n: 0, k: 0, d: 0, a: 0, r: 0 });
// Ratio de sumas (no media de ratios): K/D = Σkills/Σdeaths, y por ronda = Σx/Σrondas
const ratios = (g: Agg) => ({ n: g.n, kd: g.d ? r2(g.k / g.d) : null, kpr: r2(g.k / g.r), dpr: r2(g.d / g.r), apr: r2(g.a / g.r) });
export type Ratios = ReturnType<typeof ratios>;

/** Un punto por season (orden cronológico). */
export function kdaBySeason(matches: Match[], playlist: string): (Ratios & { season: string })[] {
  const by = new Map<string, Match[]>();
  for (const m of matches) if (usable(m, playlist)) (by.get(m.season) ?? by.set(m.season, []).get(m.season)!).push(m);
  return [...by].sort((a, b) => seasonKey(a[0]) - seasonKey(b[0])).map(([season, ms]) => ({ season, ...ratios(agg(ms)) }));
}

/** Media móvil de las últimas `win` partidas dentro de una season. */
export function kdaRolling(matches: Match[], season: string, playlist: string, win: number): (Ratios & { i: number })[] {
  const ms = matches.filter((m) => m.season === season && usable(m, playlist)).sort((a, b) => a.t - b.t);
  return ms.map((_, i) => ({ i: i + 1, ...ratios(agg(ms.slice(Math.max(0, i - win + 1), i + 1))) }));
}

/** Partidas por season y grupo de playlist (orden fijo; se omiten los grupos sin partidas). */
export function playlistCounts(matches: Match[]) {
  const seasons = [...new Set(matches.map((m) => m.season))].sort((a, b) => seasonKey(a) - seasonKey(b));
  const cnt: Record<string, Record<string, number>> = {};
  for (const m of matches) { const g = playlistGroup(m.playlist); (cnt[g] ??= {})[m.season] = (cnt[g][m.season] ?? 0) + 1; }
  const playlists = PLAYLIST_GROUPS.filter((g) => cnt[g]);
  return { seasons, playlists, counts: (p: string, s: string) => cnt[p]?.[s] ?? 0 };
}
