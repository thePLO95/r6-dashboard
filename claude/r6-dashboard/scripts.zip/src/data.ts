export type Match = {
  id: string; season: string; playlist: string; i: number; t: number;
  mode: string | null; map: string | null; res: string;
  k: number | null; d: number | null; a: number | null; hs: number | null;
  rounds: number | null; rw: number | null;
  rp: number | null; rpPrev: number | null; rpD: number | null; rank: string | null;
};
export type PlayerData = { name: string; avatar: string; playerId: string; matches: Match[] };
export type Index = { seasons: string[]; players: { name: string; avatar: string; seasonInfo: Record<string, { ranked: number; rated: number }> }[] };

const base = import.meta.env.BASE_URL + 'data/';
const get = <T,>(p: string) => fetch(base + p).then((r) => r.json() as Promise<T>);
export const loadIndex = () => get<Index>('index.json');
export const loadPlayer = (name: string) => get<PlayerData>(`players/${encodeURIComponent(name)}.json`);

export type Metric = 'rating' | 'progress' | 'netwins';
export type XAxis = 'date' | 'match';

/** Serie [x, y] de un jugador en una season (solo ranked). Devuelve [] si no hay datos para esa métrica. */
export function rankSeries(p: PlayerData, season: string, metric: Metric, x: XAxis): [number, number][] {
  const ms = p.matches.filter((m) => m.season === season && m.playlist === 'ranked').sort((a, b) => a.t - b.t);
  const xv = (m: Match, idx: number) => (x === 'date' ? m.t : idx + 1);
  if (metric === 'netwins') {
    // Proxy válido en TODAS las temporadas: victorias - derrotas acumuladas
    let acc = 0;
    return ms.map((m, i) => { acc += m.res === 'win' ? 1 : m.res === 'loss' ? -1 : 0; return [xv(m, i), acc]; });
  }
  const rated = ms.map((m, i) => ({ m, i })).filter(({ m }) => m.rp != null);
  if (!rated.length) return [];
  if (metric === 'rating') return rated.map(({ m, i }) => [xv(m, i), m.rp!]);
  // progress: puntos respecto al inicio de season (rp anterior a la 1ª partida con dato)
  const f = rated[0].m;
  const base = f.rpPrev ?? (f.rpD != null ? f.rp! - f.rpD : f.rp!);
  return rated.map(({ m, i }) => [xv(m, i), m.rp! - base]);
}

export const seasonSummary = (p: PlayerData, season: string) => {
  const s = rankSeries(p, season, 'rating', 'date');
  const pr = rankSeries(p, season, 'progress', 'date');
  return s.length ? { start: s[0][1] - pr[0][1], end: s[s.length - 1][1], net: pr[pr.length - 1][1], peak: Math.max(...s.map((d) => d[1])) } : null;
};
