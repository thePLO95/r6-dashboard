let operator_data = {
    "solidsnake": {
        "name": "Solid Snake",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/solidsnake.png?v=2"
    },
    "jackal": {
        "name": "Jackal",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/jackal.png?v=2"
    },
    "azami": {
        "name": "Azami ",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/azami.png?v=2"
    },
    "vigil": {
        "name": "Vigil",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/vigil.png?v=2"
    },
    "ash": {
        "name": "Ash",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/ash.png?v=2"
    },
    "solis": {
        "name": "Solis",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/solis.png?v=2"
    },
    "zofia": {
        "name": "Zofia",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/zofia.png?v=2"
    },
    "amaru": {
        "name": "Amaru",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/amaru.png?v=2"
    },
    "sledge": {
        "name": "Sledge",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/sledge.png?v=2"
    },
    "noor": {
        "name": "Noor",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/noor.png?v=2"
    },
    "capitao": {
        "name": "CapitÃ£o",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/capitao.png?v=2"
    },
    "buck": {
        "name": "Buck",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/buck.png?v=2"
    },
    "wamai": {
        "name": "Wamai",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/wamai.png?v=2"
    },
    "caveira": {
        "name": "Caveira",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/caveira.png?v=2"
    },
    "alibi": {
        "name": "Alibi",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/alibi.png?v=2"
    },
    "aruni": {
        "name": "Aruni",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/aruni.png?v=2"
    },
    "goyo": {
        "name": "Goyo",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/goyo.png?v=2"
    },
    "blackbeard": {
        "name": "Blackbeard",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/blackbeard.png?v=2"
    },
    "nomad": {
        "name": "Nomad",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/nomad.png?v=2"
    },
    "ace": {
        "name": "Ace",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/ace.png?v=2"
    },
    "frost": {
        "name": "Frost",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/frost.png?v=2"
    },
    "lesion": {
        "name": "Lesion",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/lesion.png?v=2"
    },
    "dokkaebi": {
        "name": "Dokkaebi",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/dokkaebi.png?v=2"
    },
    "iq": {
        "name": "IQ",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/iq.png?v=2"
    },
    "mozzie": {
        "name": "Mozzie",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/mozzie.png?v=2"
    },
    "thatcher": {
        "name": "Thatcher",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/thatcher.png?v=2"
    },
    "fenrir": {
        "name": "Fenrir",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/fenrir.png?v=2"
    },
    "kapkan": {
        "name": "Kapkan",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/kapkan.png?v=2"
    },
    "grim": {
        "name": "Grim",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/grim.png?v=2"
    },
    "lion": {
        "name": "Lion",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/lion.png?v=2"
    },
    "tachanka": {
        "name": "Tachanka",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/tachanka.png?v=2"
    },
    "skopos": {
        "name": "SkopÃ³s",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/skopos.png?v=2"
    },
    "tubarao": {
        "name": "TubarÃ£o",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/tubarao.png?v=2"
    },
    "blitz": {
        "name": "Blitz",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/blitz.png?v=2"
    },
    "melusi": {
        "name": "Melusi",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/melusi.png?v=2"
    },
    "hibana": {
        "name": "Hibana",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/hibana.png?v=2"
    },
    "jager": {
        "name": "JÃ¤ger",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/jager.png?v=2"
    },
    "twitch": {
        "name": "Twitch",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/twitch.png?v=2"
    },
    "mute": {
        "name": "Mute",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/mute.png?v=2"
    },
    "deimos": {
        "name": "Deimos",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/deimos.png?v=2"
    },
    "flores": {
        "name": "Flores",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/flores.png?v=2"
    },
    "kaid": {
        "name": "Kaid",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/kaid.png?v=2"
    },
    "denari": {
        "name": "Denari",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/denari.png?v=2"
    },
    "gridlock": {
        "name": "Gridlock",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/gridlock.png?v=2"
    },
    "ram": {
        "name": "Ram",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/ram.png?v=2"
    },
    "rauora": {
        "name": "Rauora",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/rauora.png?v=2"
    },
    "oryx": {
        "name": "Oryx",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/oryx.png?v=2"
    },
    "thorn": {
        "name": "Thorn",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/thorn.png?v=2"
    },
    "ela": {
        "name": "Ela",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/ela.png?v=2"
    },
    "pulse": {
        "name": "Pulse",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/pulse.png?v=2"
    },
    "glaz": {
        "name": "Glaz",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/glaz.png?v=2"
    },
    "thermite": {
        "name": "Thermite",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/thermite.png?v=2"
    },
    "brava": {
        "name": "Brava",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/brava.png?v=2"
    },
    "castle": {
        "name": "Castle",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/castle.png?v=2"
    },
    "bandit": {
        "name": "Bandit",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/bandit.png?v=2"
    },
    "iana": {
        "name": "Iana",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/iana.png?v=2"
    },
    "sens": {
        "name": "Sens",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/sens.png?v=2"
    },
    "striker": {
        "name": "Striker",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/striker.png?v=2"
    },
    "ying": {
        "name": "Ying",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/ying.png?v=2"
    },
    "smoke": {
        "name": "Smoke",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/smoke.png?v=2"
    },
    "maverick": {
        "name": "Maverick",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/maverick.png?v=2"
    },
    "kali": {
        "name": "Kali",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/kali.png?v=2"
    },
    "montagne": {
        "name": "Montagne",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/montagne.png?v=2"
    },
    "finka": {
        "name": "Finka",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/finka.png?v=2"
    },
    "osa": {
        "name": "Osa",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/osa.png?v=2"
    },
    "nokk": {
        "name": "NÃ¸kk",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/nokk.png?v=2"
    },
    "mira": {
        "name": "Mira",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/mira.png?v=2"
    },
    "fuze": {
        "name": "Fuze",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/fuze.png?v=2"
    },
    "valkyrie": {
        "name": "Valkyrie",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/valkyrie.png?v=2"
    },
    "doc": {
        "name": "Doc",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/doc.png?v=2"
    },
    "warden": {
        "name": "Warden",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/warden.png?v=2"
    },
    "rook": {
        "name": "Rook",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/rook.png?v=2"
    },
    "zero": {
        "name": "Zero",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/zero.png?v=2"
    },
    "clash": {
        "name": "Clash",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/clash.png?v=2"
    },
    "maestro": {
        "name": "Maestro",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/maestro.png?v=2"
    },
    "echo": {
        "name": "Echo",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/echo.png?v=2"
    },
    "sentry": {
        "name": "Sentry",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/sentry.png?v=2"
    },
    "thunderbird": {
        "name": "Thunderbird",
        "imageUrl": "https://trackercdn.com/cdn/r6.tracker.network/operators/badges/thunderbird.png?v=2"
    }
};