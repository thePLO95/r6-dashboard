let map_data = {
    "villa": {
        "name": "Villa",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/villa.jpg"
    },
    "kafe-dostoyevsky": {
        "name": "Kafe Dostoyevsky",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/kafe-dostoyevsky.jpg"
    },
    "theme-park": {
        "name": "Theme Park",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/theme-park.jpg"
    },
    "clubhouse": {
        "name": "Clubhouse",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/clubhouse.jpg"
    },
    "oregon": {
        "name": "Oregon",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/oregon.jpg"
    },
    "fortress": {
        "name": "Fortress",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/fortress.jpg"
    },
    "bank": {
        "name": "Bank",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/bank.jpg"
    },
    "M.U.T.E. COMM TOWER": {
        "name": "M.U.T.E. COMM TOWER",
        "imageURL": null
    },
    "presidential-plane": {
        "name": "Presidential Plane",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/presidential-plane.jpg"
    },
    "coastline": {
        "name": "Coastline",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/coastline.jpg"
    },
    "emerald-plains": {
        "name": "Emerald Plains",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/emerald-plains.jpg"
    },
    "nighthaven-labs": {
        "name": "Nighthaven Labs",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/nighthaven-labs.jpg"
    },
    "border": {
        "name": "Border",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/border.jpg"
    },
    "outback": {
        "name": "Outback",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/outback.jpg"
    },
    "kanal": {
        "name": "Kanal",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/kanal.jpg"
    },
    "consulate": {
        "name": "Consulate",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/consulate.jpg"
    },
    "skyscraper": {
        "name": "Skyscraper",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/skyscraper.jpg"
    },
    "chalet": {
        "name": "Chalet",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/chalet.jpg"
    },
    "house": {
        "name": "House",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/house.jpg"
    },
    "glacial-facility": {
        "name": "Glacial Facility",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/glacial-facility.jpg"
    },
    "arctic-workshop": {
        "name": "Arctic Workshop",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/arctic-workshop.jpg"
    },
    "lair": {
        "name": "Lair",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/lair.jpg"
    },
    "shinden": {
        "name": "Shinden",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/shinden.jpg"
    },
    "fort-truth": {
        "name": "Fort Truth",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/fort-truth.jpg"
    },
    "calypso-casino": {
        "name": "Calypso Casino",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/calypso-casino.jpg"
    },
    "district": {
        "name": "District",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/district.jpg"
    },
    "rainbow-hq": {
        "name": "Rainbow HQ",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/rainbow-hq.jpg"
    },
    "stadium-alpha": {
        "name": "Stadium Alpha",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/stadium-alpha.jpg"
    },
    "close-quarter": {
        "name": "Close Quarter",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/close-quarter.jpg"
    },
    "yacht": {
        "name": "Yacht",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/yacht.jpg"
    },
    "post-apocalyptic-oregon": {
        "name": "Post-Apocalyptic Oregon",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/post-apocalyptic-oregon.jpg"
    },
    "favela": {
        "name": "Favela",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/favela.jpg"
    },
    "tower": {
        "name": "Tower",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/tower.jpg"
    },
    "stadium-bravo": {
        "name": "Stadium Bravo",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/stadium-bravo.jpg"
    },
    "doktors-castle": {
        "name": "Doktor's Castle",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/doktors-castle.jpg"
    },
    "hereford-base": {
        "name": "Hereford Base",
        "imageURL": "https://trackercdn.com/cdn/r6.tracker.network/images/maps/hereford-base.jpg"
    },
    "AIR CUTE ONE": {
        "name": "AIR CUTE ONE",
        "imageURL": null
    },
    "DOKTOR'S LAB": {
        "name": "DOKTOR'S LAB",
        "imageURL": null
    }
};