let seasonData = [
	{releaseDate: new Date("2016-02-02T12:00:00.000+00:00"), id: "Y1S1", seasonName:"Operation Black Ice"},
	{releaseDate: new Date("2016-05-10T12:00:00.000+00:00"), id: "Y1S2", seasonName:"Operation Dust Line"},
	{releaseDate: new Date("2016-08-02T12:00:00.000+00:00"), id: "Y1S3", seasonName:"Operation Skull Rain"},
	{releaseDate: new Date("2016-11-17T12:00:00.000+00:00"), id: "Y1S4", seasonName:"Operation Red Crow"},

	{releaseDate: new Date("2017-02-07T12:00:00.000+00:00"), id: "Y2S1", seasonName:"Operation Velvet Shell"},
	{releaseDate: new Date("2017-06-07T12:00:00.000+00:00"), id: "Y2S2", seasonName:"Operation Health"},
	{releaseDate: new Date("2017-09-05T12:00:00.000+00:00"), id: "Y2S3", seasonName:"Operation Blood Orchid"},
	{releaseDate: new Date("2017-12-05T12:00:00.000+00:00"), id: "Y2S4", seasonName:"Operation White Noise"},

	{releaseDate: new Date("2018-03-06T12:00:00.000+00:00"), id: "Y3S1", seasonName:"Operation Chimera"},
	{releaseDate: new Date("2018-06-07T12:00:00.000+00:00"), id: "Y3S2", seasonName:"Operation Para Bellum"},
	{releaseDate: new Date("2018-09-04T12:00:00.000+00:00"), id: "Y3S3", seasonName:"Operation Grim Sky"},
	{releaseDate: new Date("2018-12-04T12:00:00.000+00:00"), id: "Y3S4", seasonName:"Operation Wind Bastion"},

	{releaseDate: new Date("2019-03-06T12:00:00.000+00:00"), id: "Y4S1", seasonName:"Operation Burnt Horizon"},
	{releaseDate: new Date("2019-06-11T12:00:00.000+00:00"), id: "Y4S2", seasonName:"Operation Phantom Sight"},
	{releaseDate: new Date("2019-09-11T12:00:00.000+00:00"), id: "Y4S3", seasonName:"Operation Ember Rise"},
	{releaseDate: new Date("2019-12-03T12:00:00.000+00:00"), id: "Y4S4", seasonName:"Operation Shifting Tides"},

	{releaseDate: new Date("2020-03-10T12:00:00.000+00:00"), id: "Y5S1", seasonName:"Operation Void Edge"},
	{releaseDate: new Date("2020-06-16T12:00:00.000+00:00"), id: "Y5S2", seasonName:"Operation Steel Wave"},
	{releaseDate: new Date("2020-09-10T12:00:00.000+00:00"), id: "Y5S3", seasonName:"Operation Shadow Legacy"},
	{releaseDate: new Date("2020-12-01T12:00:00.000+00:00"), id: "Y5S4", seasonName:"Operation Neon Dawn"},

	{releaseDate: new Date("2021-03-16T12:00:00.000+00:00"), id: "Y6S1", seasonName:"Operation Crimson Heist"},
	{releaseDate: new Date("2021-06-14T12:00:00.000+00:00"), id: "Y6S2", seasonName:"Operation North Star"},
	{releaseDate: new Date("2021-09-07T12:00:00.000+00:00"), id: "Y6S3", seasonName:"Operation Crystal Guard"},
	{releaseDate: new Date("2021-11-30T12:00:00.000+00:00"), id: "Y6S4", seasonName:"Operation High Calibre"},

	{releaseDate: new Date("2022-03-15T12:00:00.000+00:00"), id: "Y7S1", seasonName:"Operation Demon Veil"},
	{releaseDate: new Date("2022-06-14T12:00:00.000+00:00"), id: "Y7S2", seasonName:"Operation Vector Glare"},
	{releaseDate: new Date("2022-09-06T12:00:00.000+00:00"), id: "Y7S3", seasonName:"Operation Brutal Swarm"},
	{releaseDate: new Date("2022-12-06T12:00:00.000+00:00"), id: "Y7S4", seasonName:"Operation Solar Raid"},

	{releaseDate: new Date("2023-03-07T12:00:00.000+00:00"), id: "Y8S1", seasonName:"Operation Commanding Force"},
	{releaseDate: new Date("2023-05-30T12:00:00.000+00:00"), id: "Y8S2", seasonName:"Operation Dread Factor"},
	{releaseDate: new Date("2023-09-29T12:00:00.000+00:00"), id: "Y8S3", seasonName:"Operation Heavy Mettle"},
	{releaseDate: new Date("2023-12-06T12:00:00.000+00:00"), id: "Y8S4", seasonName:"Operation Deep Freeze"},

	{releaseDate: new Date("2024-03-12T12:00:00.000+00:00"), id: "Y9S1", seasonName:"Operation Deadly Omen"},
	{releaseDate: new Date("2024-06-11T12:00:00.000+00:00"), id: "Y9S2", seasonName:"Operation New Blood"},
	{releaseDate: new Date("2024-09-10T12:00:00.000+00:00"), id: "Y9S3", seasonName:"Operation Twin Shells"},
	{releaseDate: new Date("2024-12-03T12:00:00.000+00:00"), id: "Y9S4", seasonName:"Operation Collision Point"},

	{releaseDate: new Date("2025-03-04T12:00:00.000+00:00"), id: "Y10S1", seasonName:"Operation Prep Phase"},
	{releaseDate: new Date("2025-06-11T12:00:00.000+00:00"), id: "Y10S2", seasonName:"Operation Daybreak"},
	{releaseDate: new Date("2025-09-02T12:00:00.000+00:00"), id: "Y10S3", seasonName:"Operation High Stakes"},
	{releaseDate: new Date("2025-12-02T12:00:00.000+00:00"), id: "Y10S4", seasonName:"Operation Tenfold Pursuit"},

	{releaseDate: new Date("2026-03-03T12:00:00.000+00:00"), id: "Y11S1", seasonName:"Operation Silent Hunt"},
	{releaseDate: new Date("2026-06-02T12:00:00.000+00:00"), id: "Y11S2", seasonName:"Operation System Override"},
	{releaseDate: new Date("2026-09-01T12:00:00.000+00:00"), id: "Y11S3", seasonName:"Operation Split Fire"},
	{releaseDate: new Date("2026-12-01T12:00:00.000+00:00"), id: "Y11S4", seasonName:""},

	{releaseDate: new Date("2027-03-10T12:00:00.000+00:00"), id: "Y12S1", seasonName:""},
	{releaseDate: new Date("2027-06-15T12:00:00.000+00:00"), id: "Y12S2", seasonName:""},
	{releaseDate: new Date("2027-09-10T12:00:00.000+00:00"), id: "Y12S3", seasonName:""},
	{releaseDate: new Date("2027-12-01T12:00:00.000+00:00"), id: "Y12S4", seasonName:""},
];